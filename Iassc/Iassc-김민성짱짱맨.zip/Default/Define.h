#pragma once

#define		WINCX		800
#define		WINCY		600

#define		PI			3.141592f

#define		PURE		= 0


#define		OBJ_NOEVENT  0
#define		OBJ_DEAD	 1
#define		VK_MAX		 0xff

extern HWND			g_hWnd;